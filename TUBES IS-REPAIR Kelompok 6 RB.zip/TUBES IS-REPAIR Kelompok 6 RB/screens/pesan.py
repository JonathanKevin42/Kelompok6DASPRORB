from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.dropdown import DropDown
from kivy.core.window import Window
from kivy.lang import Builder
from kivymd.app import MDApp
from kivymd.uix.screen import MDScreen
from kivy.lang import Builder
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.scrollview import ScrollView
from kivy.uix.textinput import TextInput
from kivy.properties import ObjectProperty
# Main App Class
class Pesan(MDScreen):
    def __init__(self, **kw):
        Builder.load_file("kv//pesan.kv")
        super().__init__(**kw)

    def build(self):
        self.root = ChatLayout()
        return self.root


# Main Chat Layout
class ChatLayout(BoxLayout):

    # Initialize Chatbot widget
    chatbot = ObjectProperty(None)

    def __init__(self, **kwargs):
        super(ChatLayout, self).__init__(**kwargs)

        # Create ScrollView for chat messages
        self.chatbot.messages_scroll_view = ScrollView(size_hint=(1, .9), pos_hint={'x': 0, 'y': .1})

        # Add ScrollView to Chatbot widget
        self.chatbot.add_widget(self.chatbot.messages_scroll_view)

        # Create TextInput for user messages
        self.user_message = TextInput(size_hint=(1, .1), pos_hint={'x': 0, 'y': 0})

        # Add TextInput to Chatbot widget
        self.chatbot.add_widget(self.user_message)


# Chatbot Widget
class Chatbot(BoxLayout):

    # Initialize properties for chat messages
    messages_box = ObjectProperty(None)
    messages_scroll_view = ObjectProperty(None)

    def __init__(self, **kwargs):
        super(Chatbot, self).__init__(**kwargs)

        # Create a vertical box layout for chat messages
        self.messages_box = BoxLayout(orientation='vertical', size_hint=(1, None), height='200dp')

        # Add chat messages box to ScrollView
        self.messages_scroll_view.add_widget(self.messages_box)

    # Function to add a message to the chatbot
    def add_message(self, message):
        self.messages_box.add_widget(Message(text=message))

        # Update ScrollView position to display latest message
        self.messages_scroll_view.scroll_to(self.messages_box)


# Message Widget
class Message(BoxLayout):

    # Initialize function for message widget
    def __init__(self, text, **kwargs):
        super(Message, self).__init__(**kwargs)

        # Create a label for the message text
        self.message_label = Label(text=text, size_hint=(None, 1), width='200dp')

        # Add message label to message widget
        self.add_widget(self.message_label)