import textwrap
from typing import Text
from kivymd.app import MDApp
from kivymd.uix.screen import MDScreen
from kivy.lang import Builder
from kivymd.uix.dialog import MDDialog
import sqlite3
import bcrypt
from kivymd.uix.button import MDFlatButton,MDRectangleFlatButton
from kivy.uix.button import Button
from screens.home import Home
from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.properties import StringProperty
from kivy.clock import Clock
from kivy.uix.label import Label
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.textinput import TextInput
import os
from kivy.uix.screenmanager import ScreenManager, Screen
from main import IREPAIR

# Create a class for the home screen
class HomeScreen(Screen):
    pass

# Create a class for the screen manager
class ScreenManagerApp(ScreenManager):
    pass

class Hallog(MDScreen):
    pass

    def __init__(self, **kwargs):
        Builder.load_file("kv/hallog.kv")
        super().__init__(**kwargs)
    
    def change_screen(self, screen_name):
        self.screen_manager = 'home'

    def build(self):
        # Initialize the screen manager
        sm = ScreenManagerApp()
        # Add the sign-in screen
        sm.add_widget(Hallog(name="signin"))
        # Add the home screen
        sm.add_widget(HomeScreen(name="home"))
        return sm


    def loginAcc(self):
        username = self.ids.username.text
        password = self.ids.password.text

        if not len(username or password) < 1:
            if True:
                conn = sqlite3.connect('screens/tubes.db')
                c = conn.cursor()
                c.execute("SELECT * FROM member")

                db = c.fetchall()
                l = []
                n = []
                for user in db:
                    a = (user[1])
                    z = (user[6])
                    l.append(a)
                    n.append(z)
                    userdata = dict(zip(l, n))
                    #userdata = (l,n)
                try:
                    if username in userdata:
                        user = userdata[username]

                        try:
                            if  bcrypt.checkpw(password.encode(), user):
                                print("Berhasil login!")
                                print("Hi", username)
                                App.get_running_app().root.current = "home"
                            else:
                                print()
                                self.dialog = MDDialog(
                                    text = "Password salah!.untuk mengulangi klik di luar box",
                                    radius=[20, 7, 20, 7],
                                    )
                                self.dialog.open()
                        except:
                            print()
                            self.dialog = MDDialog(
                                text = "Mohon password dan username periksa kembali!.untuk mengulangi klik di luar box",
                                radius=[20, 7, 20, 7],
                                ) 
                            self.dialog.open()
                    else:
                        print()
                        self.dialog = MDDialog(
                            text = "Maaf username tidak terdaftar!.untuk mengulangi klik di luar box",
                            radius=[20, 7, 20, 7],
                            )
                        self.dialog.open()
                except:
                    print()
                    self.dialog = MDDialog(
                        text = "Password atau username belum terdaftar!.untuk mengulangi klik di luar box",
                        radius=[20, 7, 20, 7],
                        )
                    self.dialog.open()
            else:
                print()
                self.dialog = MDDialog(
                    text = "Gagal login!.untuk mengulangi klik di luar box",
                    radius=[20, 7, 20, 7],
                    )
                self.dialog.open()
        else:
            print()
            self.dialog = MDDialog(
                text = "Password dan username tidak boleh kosong!.untuk mengulangi klik di luar box",
                radius=[20, 7, 20, 7],
                )
            self.dialog.open()
 