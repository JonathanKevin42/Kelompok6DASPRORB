from kivy.lang import Builder
from kivymd.app import MDApp
from kivymd.uix.screen import MDScreen


class Home(MDScreen):
    pass

    def __init__(self, **kw):
        Builder.load_file("kv//home.kv")
        super().__init__(**kw)
        

    def build(self):
        self.title='KivyMD Dashboard'
        self.theme_cls.theme_style = "Dark"
        self.theme_cls.primary_palette = "DeepPurple"

