from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.dropdown import DropDown
from kivy.uix.button import Button
from kivy.lang import Builder
from kivymd.uix.screen import MDScreen


class List(MDScreen):
    pass
    def __init__(self, **kwargs):
        Builder.load_file("kv/list.kv")
        super().__init__(**kwargs)

class MenuDropdown(BoxLayout):
    def __init__(self, **kwargs):
        super(MenuDropdown, self).__init__(**kwargs)
        self.dropdown = DropDown()
        for type in ["Xiaomi", "Samsung", "Oppo", "Vivo", "iPhone"]:
            btn = List(text=type, size_hint_y=None, height=40)
            btn.bind(on_release=lambda btn: self.dropdown.select(btn.text))
            self.dropdown.add_widget(btn)

    def on_select(self, instance, type):
        print("Selected brand: {}".format(type))

    def build(self):
        dropdown = MenuDropdown()
        mainbutton = Button(text="Choose brand", size_hint=(None, None))
        mainbutton.bind(on_release=dropdown.dropdown.open)
        dropdown.add_widget(mainbutton)
        return dropdown

