from kivymd.app import MDApp
from kivymd.uix.screen import MDScreen
from kivy.lang import Builder
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.properties import ObjectProperty
from kivy.uix.widget import Widget
from kivy_garden.mapview import MapView
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.properties import StringProperty
from kivy.uix.screenmanager import Screen
from kivy.properties import StringProperty
import sqlite3
from kivymd.uix.dialog import MDDialog
class pythonform(MDScreen):
    pass

    label = StringProperty()
    lokasi = StringProperty()
    kerusakan = StringProperty()
    budget_label = StringProperty()
    hp_brand = StringProperty()
    hp_component = StringProperty()

    def on_submit(self):
        conn = sqlite3.connect('screens/tubes.db')
        c = conn.cursor()

        data = (self.ids.click_label.text, self.ids.lokasi.text, self.ids.kerusakan.text, self.ids.budget_label.text, self.ids.hp_brand.text, self.ids.hp_component.text)
        c.execute("INSERT INTO form (label,lokasi, kerusakan, budget, brand, component) VALUES (?, ?, ?, ?, ?, ?)", data)


      
    
        conn.commit()
        conn.close()
        print()
        #jika berhasil insert atau daftar 
        self.dialog = MDDialog(
        title="S E L A M A T",
        text="Pesanan Anda sudah Terekam, Tunggu Hingga Status hp anda selesai pada menu Status",
        radius=[20, 7, 20, 7],
        )
        self.dialog.open()

    def on_hp_brand(self, brand):
        self.hp_brand = brand

    def on_hp_component(self, component):
        self.hp_component = component

    def spinner_clicked(self, value):
        self.ids.click_label.text = f'Kamu memilih: {value}'

    def __init__(self, **kwa):
        Builder.load_file("kv/pythonform.kv")
        super().__init__(**kwa)
        
    def on_hp_brand(self, text):
        brand_prices = {
            'Samsung': {'LCD': 500000, 'Baterai': 350000, 'Mesin': 1000000, 'Speaker': 150000, 'Kamera': 250000, 'Tombol' : 50000},
            'Oppo': {'LCD': 400000, 'Baterai': 300000, 'Mesin': 800000, 'Speaker': 100000, 'Kamera': 200000, 'Tombol' : 35000},
            'Vivo': {'LCD': 450000, 'Baterai': 350000, 'Mesin': 900000, 'Speaker': 120000, 'Kamera': 220000, 'Tombol' : 35000},
            'Xiaomi': {'LCD': 350000, 'Baterai': 250000, 'Mesin': 700000, 'Speaker': 120000, 'Kamera': 220000, 'Tombol' : 25000},
            'Realme': {'LCD': 300000, 'Baterai': 250000, 'Mesin': 600000, 'Speaker': 100000, 'Kamera': 200000, 'Tombol' : 30000},
        }
        component = self.ids.hp_component.text
        if component:
            budget = brand_prices[text][component]
            self.ids.budget_label.text = f'Rp.{budget:,} ,-'

    def on_hp_component(self, text):
        self.on_hp_brand(self.ids.hp_brand.text)




