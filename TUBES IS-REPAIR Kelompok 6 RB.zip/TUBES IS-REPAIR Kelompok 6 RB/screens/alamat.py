from kivy.app import App
from kivy.uix.boxlayout import BoxLayout    
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.dropdown import DropDown
from kivy.core.window import Window
from kivy.lang import Builder
from kivymd.app import MDApp
from kivymd.uix.screen import MDScreen
from kivy.lang import Builder

class Alamat(MDScreen):
    def __init__(self, **kw):
        Builder.load_file("kv//alamat.kv")
        super().__init__(**kw)