from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.dropdown import DropDown
from kivy.core.window import Window
from kivy.lang import Builder
from kivymd.app import MDApp
from kivymd.uix.screen import MDScreen
from kivy.lang import Builder
from kivy.uix.dropdown import DropDown
from kivy.uix.button import Button
from kivy.uix.boxlayout import BoxLayout
from kivy.app import App
from kivy.core.window import Window
from kivy.lang import Builder
import pandas as pd
from kivymd.uix.anchorlayout import MDAnchorLayout

class Smartphone(BoxLayout):
    def __init__(self, **kw):
        Builder.load_file("kv//smartphone.kv")
        super().__init__(**kw)
class Smartphone(MDScreen):


    def __init__(self, **kwargs):
        Builder.load_file("kv//smartphone.kv")
        super(Smartphone, self).__init__(**kwargs)
        self.dropdown = DropDown()
        self.data = pd.read_excel('smartphone_data.xlsx')
        for i in range(len(self.data)):
            btn = Button(text=str(self.data.loc[i, 'Model']), size_hint_y=None, height=44)
            btn.bind(on_release=lambda btn: self.dropdown.select(btn.text))
            self.dropdown.add_widget(btn)

        self.dropdown.bind(on_select=lambda instance, text: self.update_detail(text))

        self.dropdown_button = Button(text='Select model',font_size = "16sp",size_hint=(0.46, 0.07), pos_hint={"center_x": 0.33, "center_y": 0.16})
        self.dropdown_button.bind(on_release=self.dropdown.open)
        self.dropdown_button.dropdown = self.dropdown
        self.add_widget(self.dropdown_button)

        self.box = BoxLayout(orientation='vertical',size_hint=(1,1))
        self.add_widget(self.box)

    def update_detail(self, model):
        data = pd.read_excel('smartphone_data.xlsx')
        row = data[data['Model'] == model]
        detail = row.to_dict('records')[0]

        harga = detail['Harga']
        spesifikasi = detail['Spesifikasi']

        self.box.clear_widgets()

        self.harga = Label(text=harga,font_size="40dp",pos_hint={"center_x": 0.5, "center_y": 0.1})
        self.spesifikasi = Label(text=spesifikasi,font_size="15dp",halign='center',valign='center',pos_hint={"center_x": 0.5, "center_y": 1})

        self.box.add_widget(self.harga)
        self.box.add_widget(self.spesifikasi)