from kivy.app import App
from kivy.uix.dropdown import DropDown
from kivy.uix.boxlayout import BoxLayout
from kivy.lang import Builder
from kivy.uix.button import Button
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.dropdown import DropDown
from kivy.core.window import Window
from kivy.lang import Builder
from kivymd.app import MDApp
from kivymd.uix.screen import MDScreen
from kivy.uix.floatlayout import FloatLayout
from kivy.properties import ObjectProperty
from kivy.uix.dropdown import DropDown
from kivymd.uix.boxlayout import MDBoxLayout
from kivy.uix.dropdown import DropDown
from kivy.uix.boxlayout import BoxLayout
from kivy.lang import Builder
from kivy.uix.button import Button
from kivymd.uix.widget import Widget

class Harga(MDScreen):
    def __init__(self, **kw):
        Builder.load_file("kv//harga.kv")
        super().__init__(**kw)
    
    def on_hp_brand(self, text):
        brand_prices = {
            'Samsung': {'LCD': 500000, 'Baterai': 350000, 'Mesin': 1000000, 'Speaker': 150000, 'Kamera': 250000, 'Tombol' : 50000},
            'Oppo': {'LCD': 400000, 'Baterai': 300000, 'Mesin': 800000, 'Speaker': 100000, 'Kamera': 200000, 'Tombol' : 35000},
            'Vivo': {'LCD': 450000, 'Baterai': 350000, 'Mesin': 900000, 'Speaker': 120000, 'Kamera': 220000, 'Tombol' : 35000},
            'Xiaomi': {'LCD': 350000, 'Baterai': 250000, 'Mesin': 700000, 'Speaker': 120000, 'Kamera': 220000, 'Tombol' : 25000},
            'Realme': {'LCD': 300000, 'Baterai': 250000, 'Mesin': 600000, 'Speaker': 100000, 'Kamera': 200000, 'Tombol' : 30000},
        }
        component = self.ids.hp_component.text
        if component:
            budget = brand_prices[text][component]
            self.ids.budget_label.text = f'Rp.{budget:,} ,-'

    def on_hp_component(self, text):
        self.on_hp_brand(self.ids.hp_brand.text)
    

